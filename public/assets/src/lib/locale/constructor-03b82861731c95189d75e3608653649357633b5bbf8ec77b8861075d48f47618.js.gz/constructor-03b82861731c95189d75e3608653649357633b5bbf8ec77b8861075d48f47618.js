export function Locale(config) {
    if (config != null) {
        this.set(config);
    }
}
;
