export default function mod(n, x) {
    return ((n % x) + x) % x;
}
;
