
var Sticky = require('./dist/sticky.compile.js');

module.exports = Sticky;
